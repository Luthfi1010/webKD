# hospitaladmin
Hospital - Bootstrap 5 &amp; Material Design Admin Template<br>
[Live demo
](https://therichpost.com/hospital-bootstrap-5-material-design-admin-template/)
